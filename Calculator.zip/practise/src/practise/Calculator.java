package practise;
import java.util.Scanner;
public class Calculator {
	public static void main(String[] args) {
		int a,b;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the numbers :");
		a=sc.nextInt();
		b=sc.nextInt();
		int option;
		System.out.println("Enter the option :");
		option=sc.nextInt();
		switch(option) {
		case 1:
			System.out.println("addition" +(a+b));
			break;
		case 2:
			System.out.println("subtraction :" +(a-b));
			break;	
		case 3:
			System.out.println("multiplication :" +(a*b));
			break;	
		case 4:
			System.out.println("division :" +(a/b));
			break;	
		case 5:
			System.out.println("modulus :" +(a%b));
			break;	
		default:
			System.out.println("Inalid option.please choose between 1 to 5");
	}
}  }

